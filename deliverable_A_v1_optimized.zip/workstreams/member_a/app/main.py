from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from adapters.assist import AssistAdapterError, build_assist_adapter
from adapters.dispatch import MockDispatchAdapter
from registration import (
    RegistrationError,
    RegistrationService,
    ValidationError,
    ConflictError,
    NotFoundError,
)

ROOT = Path(__file__).resolve().parents[1]
STATIC = Path(__file__).resolve().parent / "static"
RUNTIME = Path(os.getenv("MEMBER_A_RUNTIME_DIR", ROOT / "runtime"))
RUNTIME.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.getenv("MEMBER_A_DB_PATH", RUNTIME / "registrations.sqlite3"))
UI_LOG_PATH = Path(os.getenv("MEMBER_A_UI_LOG_PATH", RUNTIME / "ui_events.jsonl"))

app = FastAPI(title="夜归有接 · Member A P0", version="0.1.1")
app.mount("/static", StaticFiles(directory=STATIC), name="static")
registration_service = RegistrationService(DB_PATH)
assist_adapter = build_assist_adapter()
dispatch_adapter = MockDispatchAdapter()
_ui_lock = threading.Lock()


def now_cn() -> str:
    return datetime.now(timezone(timedelta(hours=8))).replace(microsecond=0).isoformat()


def registration_http_error(exc: RegistrationError) -> HTTPException:
    if isinstance(exc, NotFoundError):
        status = 404
    elif isinstance(exc, ConflictError):
        status = 409
    elif isinstance(exc, ValidationError):
        status = 422
    else:
        status = 400
    return HTTPException(status_code=status, detail={"code": exc.code, "message": str(exc)})


def required_version(payload: dict[str, Any]) -> int:
    value = payload.get("expected_version")
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise HTTPException(
            status_code=422,
            detail={"code": "validation_error", "message": "expected_version must be an integer >= 1"},
        )
    return value


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "version": app.version,
        "assist_adapter": os.getenv("ASSIST_ADAPTER", "mock"),
        "mode_notice": "mock/http adapter only; no transport solver in Member A",
    }


@app.get("/api/config")
def config() -> dict[str, Any]:
    return {
        "assist_adapter": os.getenv("ASSIST_ADAPTER", "mock"),
        "assist_base_url": os.getenv("ASSIST_BASE_URL", "") if os.getenv("ASSIST_ADAPTER", "mock") == "http" else None,
        "ui_build": "member-a-p0-0.1.1",
        "mode_notice": "mock 模式为接口联调虚构数据，不是实际出行建议。",
    }


@app.post("/api/assist")
def assist(payload: dict[str, Any]) -> JSONResponse:
    try:
        result = assist_adapter.assist(payload)
        return JSONResponse(result)
    except AssistAdapterError as exc:
        raise HTTPException(status_code=exc.status_code, detail={"code": exc.code, "message": str(exc)}) from exc


@app.post("/api/registrations")
def create_registration(request: Request, payload: dict[str, Any]) -> dict[str, Any]:
    key = request.headers.get("Idempotency-Key", "")
    try:
        return registration_service.create_registration(payload, key)
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


@app.get("/api/registrations")
def list_registrations(session_id: str | None = Query(default=None)) -> list[dict[str, Any]]:
    return registration_service.list_registrations(session_id)


@app.patch("/api/registrations/{registration_id}")
def update_registration(registration_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return registration_service.update_registration(
            registration_id,
            required_version(payload),
            dict(payload.get("patch") or {}),
        )
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


@app.post("/api/registrations/{registration_id}/cancel")
def cancel_registration(registration_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return registration_service.cancel_registration(registration_id, required_version(payload))
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


@app.post("/api/admin/expire")
def expire(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        count = registration_service.expire_registrations(payload.get("now") or now_cn())
        return {"expired_count": count}
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


@app.get("/api/admin/aggregation")
def aggregation(now: str | None = Query(default=None)) -> dict[str, Any]:
    try:
        return registration_service.export_active_groups(now or now_cn())
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


@app.get("/api/admin/events")
def registration_events(since_event_id: int = Query(default=0, ge=0)) -> list[dict[str, Any]]:
    return registration_service.export_events(since_event_id)


@app.get("/api/dispatch/preview")
def dispatch_preview(now: str | None = Query(default=None)) -> dict[str, Any]:
    try:
        agg = registration_service.export_active_groups(now or now_cn())
        return dispatch_adapter.preview(agg)
    except RegistrationError as exc:
        raise registration_http_error(exc) from exc


REQUIRED_UI_EVENT_FIELDS = {
    "session_pseudonym",
    "variant",
    "task_id",
    "event_type",
    "client_timestamp",
    "input_version",
    "plan_version",
    "duration_ms",
    "error_code",
    "mode",
}
ALLOWED_EVENT_TYPES = {
    "request_sent",
    "response_displayed",
    "response_discarded",
    "card_opened",
    "conditions_changed",
    "registration_submitted",
    "registration_cancelled",
    "task_finished",
}


@app.post("/api/ui-events")
def log_ui_event(payload: dict[str, Any]) -> dict[str, Any]:
    missing = sorted(REQUIRED_UI_EVENT_FIELDS - set(payload))
    if missing:
        raise HTTPException(status_code=422, detail={"code": "event_schema", "message": f"missing: {', '.join(missing)}"})
    if payload["event_type"] not in ALLOWED_EVENT_TYPES:
        raise HTTPException(status_code=422, detail={"code": "event_schema", "message": "unsupported event_type"})
    if payload["variant"] not in {"text", "card"}:
        raise HTTPException(status_code=422, detail={"code": "event_schema", "message": "variant must be text or card"})
    # Explicit allowlist prevents accidental logging of message/destination/private fields.
    clean = {key: payload.get(key) for key in REQUIRED_UI_EVENT_FIELDS}
    clean["event_id"] = str(uuid.uuid4())
    with _ui_lock:
        with UI_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(clean, ensure_ascii=False, sort_keys=True) + "\n")
    return {"event_id": clean["event_id"]}


@app.get("/api/ui-events", response_class=PlainTextResponse)
def export_ui_events() -> str:
    if not UI_LOG_PATH.exists():
        return ""
    return UI_LOG_PATH.read_text("utf-8")
