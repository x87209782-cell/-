from __future__ import annotations
from typing import Any


def should_accept_response(current_input_version: int, result: dict[str, Any]) -> bool:
    """UI rule mirrored in app.js: stale input versions cannot overwrite current state."""
    return result.get("input_version") == current_input_version
