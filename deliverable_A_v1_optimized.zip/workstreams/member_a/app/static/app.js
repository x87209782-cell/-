const $ = (id) => document.getElementById(id);
const state = {
  sessionId: `session-${crypto.randomUUID()}`,
  sessionPseudo: `p-${crypto.randomUUID()}`,
  partyId: `party-${crypto.randomUUID()}`,
  inputVersion: 0,
  currentRequestId: null,
  lastFingerprint: null,
  currentResult: null,
  variant: 'card',
  pendingRegistrationKey: null,
};

function isoFromLocal(value) { return value ? `${value}:00+08:00` : null; }
function localFromDate(date) {
  const pad=n=>String(n).padStart(2,'0');
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function setDefaults() {
  const now=new Date(); const ready=new Date(now.getTime()+20*60000); const end=new Date(ready.getTime()+30*60000);
  $('readyAt').value=localFromDate(ready); $('windowStart').value=localFromDate(ready); $('windowEnd').value=localFromDate(end);
}
function hardConstraints() {
  const walk=$('maxWalk').value;
  const wheelchair=$('wheelchair').value;
  return {
    max_walking_minutes: walk===''?null:Number(walk), max_transfers:null, latest_arrival_at:null,
    max_cost_cny:null, wheelchair_required: wheelchair==='null'?null:wheelchair==='true'
  };
}
function requestCore() {
  return {
    message:$('message').value.trim(), station_id:'BJN', destination_id:$('destination').value,
    ready_at:isoFromLocal($('readyAt').value), party_size:Number($('partySize').value),
    hard_constraints:hardConstraints(), preferences:['fewer_transfers'], mode:'mock', data_version:'member-a-mock-v1'
  };
}
function fingerprint(core){ return JSON.stringify(core); }
function buildRequest(){
  const core=requestCore(); const fp=fingerprint(core);
  if(fp!==state.lastFingerprint){ state.inputVersion+=1; state.currentRequestId=crypto.randomUUID(); state.lastFingerprint=fp; }
  if(state.inputVersion===0){ state.inputVersion=1; state.currentRequestId=crypto.randomUUID(); state.lastFingerprint=fp; }
  return {schema_version:'1.0',request_id:state.currentRequestId,session_id:state.sessionId,input_version:state.inputVersion,...core};
}
function markStale(){ if(state.currentResult){ $('staleBanner').classList.remove('hidden'); state.currentResult._stale=true; } }
function errorMessage(data){ return data?.detail?.message || data?.detail?.code || data?.detail || data?.message || '请求失败'; }
async function logEvent(type, extra={}){
  const payload={session_pseudonym:state.sessionPseudo,variant:state.variant,task_id:'p0-demo',event_type:type,
    client_timestamp:new Date().toISOString(),input_version:state.inputVersion||1,plan_version:state.currentResult?.plan_version??null,
    duration_ms:extra.duration_ms??null,error_code:extra.error_code??null,mode:state.currentResult?.mode??'mock'};
  try{ await fetch('/api/ui-events',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});}catch(e){}
}
async function sendAssist(){
  const req=buildRequest(); const version=req.input_version; const started=performance.now(); $('askBtn').disabled=true;
  $('result').textContent='正在获取结果…'; $('staleBanner').classList.remove('hidden'); await logEvent('request_sent');
  try{
    const resp=await fetch('/api/assist',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(req)});
    const data=await resp.json();
    if(!resp.ok) throw Object.assign(new Error(errorMessage(data)),{code:data?.detail?.code||`http_${resp.status}`});
    if(version!==state.inputVersion){ await logEvent('response_discarded'); return; }
    state.currentResult=data; state.currentResult._stale=false; $('staleBanner').classList.add('hidden'); renderResult();
    await logEvent('response_displayed',{duration_ms:Math.round(performance.now()-started)});
  }catch(e){
    if(version===state.inputVersion){ $('result').innerHTML=`<div class="notice danger"><strong>技术错误：</strong>${escapeHtml(e.message)}。这与“无可行方案/证据不足”不同，可重试。</div>`; }
    await logEvent('response_displayed',{duration_ms:Math.round(performance.now()-started),error_code:e.code||'client_error'});
  }finally{$('askBtn').disabled=false;}
}
function escapeHtml(s){ return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function fmt(v){ return v===null||v===undefined?'未知':escapeHtml(v); }
function renderMeta(r){ return `<dl class="kv"><dt>状态</dt><dd class="status status-${r.decision_status}">${fmt(r.decision_status)}</dd><dt>模式 / 数据版本</dt><dd>${fmt(r.mode)} / ${fmt(r.data_version)}</dd><dt>生成时间</dt><dd>${fmt(r.generated_at)}</dd><dt>有效至</dt><dd>${fmt(r.valid_until)}</dd><dt>方案版本</dt><dd>${fmt(r.plan_version)}</dd></dl>`; }
function semanticText(r){
  const lines=[`状态：${r.decision_status}`,`摘要：${r.summary}`,`模式/数据版本：${r.mode} / ${r.data_version}`,`生成：${r.generated_at}；有效至：${r.valid_until??'未知'}；方案版本：${r.plan_version}`];
  r.questions.forEach((q,i)=>lines.push(`补问${i+1}：${q}`));
  r.cards.forEach((c,i)=>{ lines.push(`方案${i+1}：${c.title}`); c.steps.forEach((s,j)=>lines.push(`步骤${j+1}：${s.instruction}；地点：${s.location_label??'未知'}；行动截止：${s.action_by??'未知'}`)); lines.push(`步行：${c.walking_minutes??'未知'}分钟；换乘：${c.transfer_count??'未知'}；费用：${c.estimated_cost_cny??'未知'}元；到达：${c.arrival_at??'未知'}`); lines.push(`来源ID：${c.source_ids.join(', ')||'无'}；限制：${c.limitations.join('；')||'无'}`); });
  lines.push(`证据ID：${r.evidence_ids.join(', ')||'无'}`); lines.push(`警告：${r.warnings.join('；')||'无'}`); return lines.join('\n');
}
function renderResult(){
  const r=state.currentResult; if(!r){return;} if(state.variant==='text'){ $('result').innerHTML=`${renderMeta(r)}<pre class="codebox">${escapeHtml(semanticText(r))}</pre>`; return; }
  let html=renderMeta(r)+`<p><strong>${escapeHtml(r.summary)}</strong></p>`;
  if(r.questions.length) html+=`<div class="notice">${r.questions.map(q=>`<div>• ${escapeHtml(q)}</div>`).join('')}</div>`;
  r.cards.forEach(card=>{ html+=`<article class="plan-card"><h3>${escapeHtml(card.title)}</h3>${card.steps.map((s,i)=>`<div class="step"><strong>步骤 ${i+1}</strong><br>${escapeHtml(s.instruction)}<br>地点：${fmt(s.location_label)}<br>行动截止：${fmt(s.action_by)}</div>`).join('')}<dl class="kv"><dt>步行 / 换乘</dt><dd>${fmt(card.walking_minutes)} 分钟 / ${fmt(card.transfer_count)} 次</dd><dt>费用 / 到达</dt><dd>${fmt(card.estimated_cost_cny)} 元 / ${fmt(card.arrival_at)}</dd><dt>来源ID</dt><dd>${escapeHtml(card.source_ids.join(', ')||'无')}</dd><dt>限制</dt><dd>${escapeHtml(card.limitations.join('；')||'无')}</dd></dl><details><summary>技术追溯</summary><code>${escapeHtml(card.option_id)}</code></details></article>`; });
  html+=`<div class="notice ${r.decision_status==='error'?'danger':''}"><strong>证据ID：</strong>${escapeHtml(r.evidence_ids.join(', ')||'无')}<br><strong>警告：</strong>${escapeHtml(r.warnings.join('；')||'无')}</div>`;
  $('result').innerHTML=html;
}
async function submitRegistration(){
  const core=requestCore(); if(!$('consent').checked){$('registrationFeedback').textContent='请先明确勾选同意登记。';return;}
  const start=isoFromLocal($('windowStart').value), end=isoFromLocal($('windowEnd').value); if(!start||!end){$('registrationFeedback').textContent='请填写完整时间窗。';return;}
  if(!state.pendingRegistrationKey) state.pendingRegistrationKey=crypto.randomUUID();
  const payload={session_id:state.sessionId,party_id:state.partyId,station_id:'BJN',destination_id:core.destination_id,
    ready_window_start:start,ready_window_end:end,party_size:core.party_size,hard_constraints:core.hard_constraints,
    consent_to_register:true,expires_at:end,mode:'mock'};
  try{ const resp=await fetch('/api/registrations',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':state.pendingRegistrationKey},body:JSON.stringify(payload)}); const data=await resp.json(); if(!resp.ok) throw new Error(errorMessage(data)); $('registrationFeedback').textContent=`已登记：${data.registration_id}，状态 ${data.status}，版本 ${data.version}`; await logEvent('registration_submitted'); state.pendingRegistrationKey=null; refreshMine(); }
  catch(e){ $('registrationFeedback').textContent=`登记失败：${e.message}`; }
}
async function refreshMine(){
  const resp=await fetch(`/api/registrations?session_id=${encodeURIComponent(state.sessionId)}`); const regs=await resp.json();
  if(!regs.length){$('myRegistrations').innerHTML='<div class="empty">暂无登记。</div>';return;}
  $('myRegistrations').innerHTML=regs.map(r=>`<div class="registration-row"><strong>${escapeHtml(r.destination_id)}</strong> · ${r.party_size}人 · <span class="status">${escapeHtml(r.status)}</span> · v${r.version}<br><span class="muted">${escapeHtml(r.ready_window_start)} — ${escapeHtml(r.ready_window_end)}</span>${['submitted','under_review','simulated_confirmed'].includes(r.status)?`<br><button data-cancel="${r.registration_id}" data-version="${r.version}">取消需求</button>`:''}</div>`).join('');
  document.querySelectorAll('[data-cancel]').forEach(btn=>btn.addEventListener('click',()=>cancelReg(btn.dataset.cancel,Number(btn.dataset.version))));
}
async function cancelReg(id,version){ const resp=await fetch(`/api/registrations/${id}/cancel`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expected_version:version})}); const data=await resp.json(); if(!resp.ok){alert(`取消失败：${errorMessage(data)}`);return;} await logEvent('registration_cancelled'); refreshMine(); }
async function refreshAdmin(){
  const resp=await fetch('/api/admin/aggregation'); const a=await resp.json(); const total=a.groups.reduce((s,g)=>s+g.party_size_total,0);
  $('adminSummary').innerHTML=`<div class="metric"><strong>${total}</strong>有效人数</div><div class="metric"><strong>${a.groups.length}</strong>精确条件组</div><div class="metric"><strong>${a.excluded_counts.cancelled||0}</strong>已取消记录</div><div class="metric"><strong>${a.excluded_counts.expired||0}</strong>已过期记录</div>`;
  $('groups').innerHTML=a.groups.length?a.groups.map(g=>`<div class="group-row"><strong>${escapeHtml(g.destination_id)}</strong> · ${g.party_size_total}人<br><span class="muted">${escapeHtml(g.ready_window_start)} — ${escapeHtml(g.ready_window_end)}</span><details><summary>追溯登记与版本</summary><pre>${escapeHtml(JSON.stringify(g,null,2))}</pre></details></div>`).join(''):'<div class="empty">当前没有有效登记。</div>';
}
async function dispatch(){ const resp=await fetch('/api/dispatch/preview'); const d=await resp.json(); $('dispatchResult').textContent=JSON.stringify(d,null,2); }
function markAndLogChange(){
  const fp=fingerprint(requestCore());
  if(fp!==state.lastFingerprint){
    // Invalidate an in-flight response immediately. Waiting until the next
    // submit left a race where an old result could overwrite changed input.
    state.inputVersion+=1;
    state.currentRequestId=crypto.randomUUID();
    state.lastFingerprint=fp;
  }
  markStale();
  logEvent('conditions_changed');
}

document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active')); document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active')); btn.classList.add('active'); $(btn.dataset.panel).classList.add('active'); if(btn.dataset.panel==='admin')refreshAdmin();}));
['message','destination','readyAt','partySize','maxWalk','wheelchair'].forEach(id=>$(id).addEventListener('change',markAndLogChange));
$('askBtn').addEventListener('click',sendAssist);
$('delay15Btn').addEventListener('click',()=>{ const d=new Date($('readyAt').value); d.setMinutes(d.getMinutes()+15); $('readyAt').value=localFromDate(d); markAndLogChange(); sendAssist(); });
$('walk5Btn').addEventListener('click',()=>{ $('maxWalk').value='5'; markAndLogChange(); sendAssist(); });
$('cardVariant').addEventListener('click',()=>{state.variant='card';$('cardVariant').classList.add('active');$('textVariant').classList.remove('active');renderResult();logEvent('card_opened');});
$('textVariant').addEventListener('click',()=>{state.variant='text';$('textVariant').classList.add('active');$('cardVariant').classList.remove('active');renderResult();});
$('registerBtn').addEventListener('click',submitRegistration); $('refreshMineBtn').addEventListener('click',refreshMine); $('refreshAdminBtn').addEventListener('click',refreshAdmin); $('dispatchBtn').addEventListener('click',dispatch);

(async function init(){setDefaults(); const c=await (await fetch('/api/config')).json(); $('modeBadge').textContent=`${c.assist_adapter.toUpperCase()} 模式`; $('modeNotice').textContent=c.mode_notice; refreshMine();})();
