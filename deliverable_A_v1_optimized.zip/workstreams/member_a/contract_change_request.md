# Contract change request — AggregationResult 的 mixed mode 表达

状态：**OPEN / 未擅自修改共同合同**。

## 发现

共同合同定义登记记录含 `mode=mock|historical_demo|scenario|verified_service`，并要求 v1 聚合键包含 mode；同时 `AggregationResult` 只有一个结果级 `mode`，组字段清单中没有 `mode`。因此若同一数据库同时存在两个 mode 的有效登记，一个快照无法无歧义表示每组 mode。

## 建议字段/规则

二选一，由队长决定：

1. 推荐：给每个 `groups[]` 增加 `mode`，结果级 `mode` 可删除或改为 `modes`；或
2. 保持 v1 结构：明确规定一次 `export_active_groups(now)` 只能导出单一 mode，并给函数增加 `mode` 过滤参数。

## 原因

- 避免把 mock/scenario 与 verified_service 混在同一需求人数里。
- 当前组虽然内部按 mode 分桶，但没有字段可以把该 mode 传给队长。
- 自造 `mode="mixed"` 会超出共同枚举，破坏兼容性。

## 当前兼容办法

A 的 P0 **不新增字段、不使用 `mixed`**。若当前有效记录包含多个 mode，导出会 fail closed，抛出 `aggregation_mode_conflict`。P0 演示数据库只使用 `mock`，因此不影响现有联调。队长接受变更前不修改共同合同。

## 受影响方

- A：聚合导出与管理端筛选。
- 队长：接收聚合结果并转算法输入。
- B：若对聚合快照做守恒/偏差核验，需要能区分 mode。
