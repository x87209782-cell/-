# 360px 浏览器布局检查记录

- 浏览器：Chromium headless。运行环境策略阻止 Chromium 导航至 localhost；后端 API 已另用真实 HTTP smoke test 验证。本项使用同一 HTML/CSS/JS 与 fetch stub，仅验证浏览器交互和 360px 布局。
- viewport：360px × 800px；document.scrollWidth：360px；横向溢出：无。
- 通过流程：问询 → card 渲染 → text/card 等信息切换 → 主动登记 → 管理端聚合。
- CSS：600px 以下双列降为单列；按钮/输入有文字标签；`:focus-visible` 有显式 outline；状态同时显示文字，不只依赖颜色。
- 截图：`mobile_360_result.png`、`mobile_360_admin.png`。
- 限制：这不是移动真机测试，也不是真人用户实验；fetch stub 仅用于浏览器布局检查。
