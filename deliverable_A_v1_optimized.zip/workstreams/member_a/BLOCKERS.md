# BLOCKERS

## 外部阻塞

1. **队长真实 `/v1/assist` 尚未提供地址**：因此当前功能使用共同合同 mock 完成，http adapter 已实现但未与真实服务联调。
2. **`/v1/dispatch/preview` 正式格式未冻结**：A 只展示独立 mock 的草案/未服务/求解状态，不计算车辆分配。
3. **AggregationResult 多 mode 语义缺口**：见 `contract_change_request.md`；当前 fail-closed。
4. **B 的真人探索性试用尚未执行**：A 已交 text/card 与日志，不伪造参与者、访谈或效果结论。

## 环境限制

- 当前环境无 Streamlit，因此没有扩展旧 Streamlit；选择已安装的 FastAPI + 原生前端。
- Chromium 可执行，但管理员策略阻止其导航 localhost；API 用 curl 做真实 HTTP smoke，360px 浏览器布局用 fetch stub 单独验证。

## 非阻塞边界

- 没有实时服务数据、车辆授权或模型密钥不阻塞 P0；所有 mock 明确标记。
- 不实现跨设备匿名身份识别；当前去重保证只覆盖本系统一致 `party_id`。
