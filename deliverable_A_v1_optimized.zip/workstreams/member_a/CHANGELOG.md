# CHANGELOG

## member-a-p0/0.1.1 — 2026-09-16

- 修复条件已改变但尚未再次提交时，在途旧响应仍可能被展示的竞态。
- 增加上游 Assist 响应的 request/session/input version 关联校验。
- 将过期处理与聚合快照放入同一事务，并允许过期同行组重新登记。
- 加固数值字段与 expected_version 类型校验，拒绝 bool、字符串和非有限数。
- dispatch 聚合冲突现在返回结构化 HTTP 错误；新增 4 组回归测试，共 19/19 通过。

## member-a-p0/0.1.0 — 2026-09-16

- 建立独立 FastAPI + 原生 HTML/JS 双端 P0。
- 增加 mock/http AssistAdapter 与 DecisionResult 合同校验。
- 增加 SQLite RegistrationService、迁移、幂等、partial unique 同行组约束、乐观版本、状态事件与精确聚合。
- 增加 card/text 等信息 UI、条件变化与乱序响应保护。
- 增加匿名 UI 事件 allowlist 与 JSONL 导出。
- 增加 append-only 实验基线、固定故障回放与 15 个自动测试。
- 增加 360px Chromium 布局检查与 HTTP smoke 记录。
- 发现 AggregationResult 多 mode 表达歧义，提交 contract change request，未修改共同合同。
