from __future__ import annotations

import json
import platform
import tempfile
import time
from pathlib import Path

from app.version_guard import should_accept_response
from experiments.append_only_baseline import AppendOnlyBaseline
from registration.service import RegistrationService, IdempotencyConflictError, VersionConflictError
from tests.common import payload

ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results" / "fixed_reliability_result.json"
STDOUT_RESULT = ROOT / "results" / "reliability_replay_stdout.txt"


def run_full() -> dict:
    failures = []
    checks = {}
    with tempfile.TemporaryDirectory() as td:
        db = Path(td) / "replay.sqlite3"
        fixed_now = lambda: "2026-09-16T17:00:00+08:00"
        svc = RegistrationService(db, now_provider=fixed_now)
        t0 = time.perf_counter()

        first = svc.create_registration(payload(), "dup-key")
        for _ in range(9):
            svc.create_registration(payload(), "dup-key")
        agg = svc.export_active_groups("2026-09-16T23:30:00+08:00")
        checks["duplicate_10_counts_one_group"] = len(svc.list_registrations()) == 1 and sum(g["party_size_total"] for g in agg["groups"]) == 2

        try:
            svc.create_registration(payload(party_size=3), "dup-key")
            checks["same_key_different_payload_rejected"] = False
        except IdempotencyConflictError:
            checks["same_key_different_payload_rejected"] = True

        updated = svc.update_registration(first["registration_id"], 1, {"party_size": 3})
        try:
            svc.update_registration(first["registration_id"], 1, {"party_size": 4})
            checks["concurrent_same_version_one_wins"] = False
        except VersionConflictError:
            checks["concurrent_same_version_one_wins"] = svc.get_registration(first["registration_id"])["party_size"] == 3

        cancelled = svc.cancel_registration(first["registration_id"], updated["version"])
        retried = svc.cancel_registration(first["registration_id"], updated["version"])
        checks["cancel_retry_no_revival"] = cancelled["status"] == retried["status"] == "cancelled"

        exp = svc.create_registration(payload(party_id="p-exp", expires="2026-09-16T23:25:00+08:00"), "exp")
        agg2 = svc.export_active_groups("2026-09-16T23:30:00+08:00")
        checks["expired_excluded"] = svc.get_registration(exp["registration_id"])["status"] == "expired" and all(exp["registration_id"] not in g["registration_ids"] for g in agg2["groups"])

        svc.create_registration(payload(party_id="p-null", wheelchair=None), "null")
        svc.create_registration(payload(party_id="p-false", wheelchair=False), "false")
        agg3 = svc.export_active_groups("2026-09-16T23:30:00+08:00")
        relevant = [g for g in agg3["groups"] if g["destination_id"] == "claude6:Z4"]
        checks["different_hard_constraints_not_merged"] = len(relevant) == 2
        active_sum = sum(r["party_size"] for r in svc.list_registrations() if r["status"] in {"submitted","under_review","simulated_confirmed"})
        group_sum = sum(g["party_size_total"] for g in agg3["groups"])
        checks["party_size_conservation"] = active_sum == group_sum

        checks["old_decision_response_discarded"] = not should_accept_response(2, {"input_version": 1}) and should_accept_response(2, {"input_version": 2})
        before = svc.export_events()
        svc2 = RegistrationService(db, now_provider=fixed_now)
        checks["restart_persists_state_and_events"] = svc2.export_events() == before and len(svc2.list_registrations()) == len(svc.list_registrations())
        elapsed = (time.perf_counter() - t0) * 1000

    failures = [name for name, passed in checks.items() if not passed]
    return {"module": "full_registration", "checks": checks, "passed": not failures, "failures": failures, "elapsed_ms": round(elapsed, 3)}


def run_baseline() -> dict:
    b = AppendOnlyBaseline()
    t0 = time.perf_counter()
    for _ in range(10):
        b.submit(payload())
    duplicate_people = sum(g["party_size_total"] for g in b.aggregate("2026-09-16T23:30:00+08:00"))
    exp = b.submit(payload(party_id="p-exp", expires="2026-09-16T23:25:00+08:00"))
    expired_people_still_present = any(exp["registration_id"] in g["registration_ids"] for g in b.aggregate("2026-09-16T23:30:00+08:00"))
    c = b.submit(payload(party_id="p-concurrent"))
    b.update(c["registration_id"], {"party_size": 3})
    b.update(c["registration_id"], {"party_size": 4})
    lost_update = next(r for r in b.records if r["registration_id"] == c["registration_id"])["party_size"] == 4
    b.submit(payload(party_id="p-null", wheelchair=None))
    b.submit(payload(party_id="p-false", wheelchair=False))
    merged_constraints = any(len(g["registration_ids"]) >= 2 for g in b.aggregate("2026-09-16T23:30:00+08:00"))
    elapsed = (time.perf_counter() - t0) * 1000
    return {
        "module": "append_only_experiment_baseline",
        "observed_failures": {
            "duplicate_people_after_10_retries": duplicate_people,
            "expired_record_remains_in_aggregation": expired_people_still_present,
            "last_writer_wins_lost_update": lost_update,
            "different_hard_constraints_can_merge": merged_constraints,
        },
        "elapsed_ms": round(elapsed, 3),
        "note": "Baseline is intentionally incomplete and is used only to replay failure mechanisms.",
    }


def main() -> None:
    result = {
        "experiment": "A-RQ2 fixed fault-event replay",
        "run_kind": "synthetic reliability test, not production load test",
        "environment": {"python": platform.python_version(), "platform": platform.platform()},
        "full": run_full(),
        "baseline": run_baseline(),
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    RESULT.parent.mkdir(parents=True, exist_ok=True)
    RESULT.write_text(rendered + "\n", "utf-8")
    STDOUT_RESULT.write_text(rendered + "\n", "utf-8")
    print(rendered)
    if not result["full"]["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
