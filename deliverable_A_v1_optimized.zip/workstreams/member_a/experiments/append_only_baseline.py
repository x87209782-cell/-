from __future__ import annotations

import uuid
from copy import deepcopy
from datetime import datetime
from typing import Any


class AppendOnlyBaseline:
    """Intentionally weak experiment baseline: no idempotency, no version checks, no expiry on export."""

    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []

    def submit(self, payload: dict[str, Any]) -> dict[str, Any]:
        record = deepcopy(payload)
        record.update(registration_id=str(uuid.uuid4()), status="submitted", version=1)
        self.records.append(record)
        return record

    def update(self, registration_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        record = next(r for r in self.records if r["registration_id"] == registration_id)
        record.update(deepcopy(patch))
        record["version"] += 1
        return record

    def cancel(self, registration_id: str) -> dict[str, Any]:
        return self.update(registration_id, {"status": "cancelled"})

    def aggregate(self, now: str) -> list[dict[str, Any]]:
        # Deliberately ignores expires_at and hard-constraint distinctions.
        buckets: dict[tuple[str, str, str], dict[str, Any]] = {}
        for r in self.records:
            if r["status"] == "cancelled":
                continue
            key = (r["destination_id"], r["ready_window_start"], r["ready_window_end"])
            b = buckets.setdefault(key, {"destination_id": key[0], "party_size_total": 0, "registration_ids": []})
            b["party_size_total"] += r["party_size"]
            b["registration_ids"].append(r["registration_id"])
        return list(buckets.values())
