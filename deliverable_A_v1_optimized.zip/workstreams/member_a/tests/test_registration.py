from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from registration.service import (
    RegistrationService,
    IdempotencyConflictError,
    PartyConflictError,
    VersionConflictError,
    InvalidTransitionError,
    AggregationModeConflictError,
    ValidationError,
)
from tests.common import payload


class RegistrationServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "reg.sqlite3"
        self.svc = RegistrationService(
            self.db, now_provider=lambda: "2026-09-16T17:00:00+08:00"
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_idempotent_retry_counts_once(self):
        first = self.svc.create_registration(payload(), "same-key")
        for _ in range(9):
            again = self.svc.create_registration(payload(), "same-key")
            self.assertEqual(first["registration_id"], again["registration_id"])
        agg = self.svc.export_active_groups("2026-09-16T23:30:00+08:00")
        self.assertEqual(sum(g["party_size_total"] for g in agg["groups"]), 2)
        self.assertEqual(len(self.svc.list_registrations()), 1)

    def test_same_key_different_payload_conflicts(self):
        self.svc.create_registration(payload(), "key")
        changed = payload(party_size=3)
        with self.assertRaises(IdempotencyConflictError):
            self.svc.create_registration(changed, "key")

    def test_same_party_only_one_active(self):
        self.svc.create_registration(payload(), "k1")
        with self.assertRaises(PartyConflictError):
            self.svc.create_registration(payload(start="2026-09-16T23:30:00+08:00", end="2026-09-17T00:00:00+08:00"), "k2")

    def test_optimistic_version_blocks_lost_update(self):
        reg = self.svc.create_registration(payload(), "k")
        a = self.svc.update_registration(reg["registration_id"], 1, {"party_size": 3})
        self.assertEqual(a["version"], 2)
        with self.assertRaises(VersionConflictError):
            self.svc.update_registration(reg["registration_id"], 1, {"party_size": 4})
        self.assertEqual(self.svc.get_registration(reg["registration_id"])["party_size"], 3)

    def test_cancel_retry_no_negative_or_revival(self):
        reg = self.svc.create_registration(payload(), "k")
        cancelled = self.svc.cancel_registration(reg["registration_id"], 1)
        self.assertEqual(cancelled["status"], "cancelled")
        retry = self.svc.cancel_registration(reg["registration_id"], 1)
        self.assertEqual(retry["version"], 2)
        agg = self.svc.export_active_groups("2026-09-16T23:30:00+08:00")
        self.assertEqual(sum(g["party_size_total"] for g in agg["groups"]), 0)
        with self.assertRaises(InvalidTransitionError):
            self.svc.update_registration(reg["registration_id"], 2, {"status": "submitted"})

    def test_expiry_excluded_and_persisted(self):
        reg = self.svc.create_registration(payload(expires="2026-09-16T23:25:00+08:00"), "k")
        agg = self.svc.export_active_groups("2026-09-16T23:30:00+08:00")
        self.assertEqual(agg["groups"], [])
        self.assertEqual(self.svc.get_registration(reg["registration_id"])["status"], "expired")
        self.assertEqual(agg["excluded_counts"]["expired"], 1)

    def test_hard_constraints_null_and_false_do_not_merge(self):
        self.svc.create_registration(payload(party_id="p1", wheelchair=None), "k1")
        self.svc.create_registration(payload(party_id="p2", wheelchair=False), "k2")
        agg = self.svc.export_active_groups("2026-09-16T23:30:00+08:00")
        self.assertEqual(len(agg["groups"]), 2)
        self.assertEqual(sum(g["party_size_total"] for g in agg["groups"]), 4)

    def test_mixed_modes_fail_closed_until_contract_resolved(self):
        self.svc.create_registration(payload(party_id="pm", mode="mock"), "km")
        self.svc.create_registration(payload(party_id="ps", mode="scenario"), "ks")
        with self.assertRaises(AggregationModeConflictError):
            self.svc.export_active_groups("2026-09-16T23:30:00+08:00")

    def test_state_progression_and_verified_service_guard(self):
        reg = self.svc.create_registration(payload(), "k")
        reg = self.svc.update_registration(reg["registration_id"], 1, {"status": "under_review"})
        reg = self.svc.update_registration(reg["registration_id"], 2, {"status": "simulated_confirmed"})
        reg = self.svc.update_registration(reg["registration_id"], 3, {"status": "completed"})
        self.assertEqual(reg["status"], "completed")
        agg = self.svc.export_active_groups("2026-09-16T23:30:00+08:00")
        self.assertEqual(agg["groups"], [])

        other = self.svc.create_registration(payload(party_id="pv", mode="verified_service"), "kv")
        other = self.svc.update_registration(other["registration_id"], 1, {"status": "under_review"})
        with self.assertRaises(InvalidTransitionError):
            self.svc.update_registration(other["registration_id"], 2, {"status": "simulated_confirmed"})

    def test_event_and_restart_consistency(self):
        reg = self.svc.create_registration(payload(), "k")
        self.svc.update_registration(reg["registration_id"], 1, {"status": "under_review"})
        events_before = self.svc.export_events()
        svc2 = RegistrationService(
            self.db, now_provider=lambda: "2026-09-16T17:00:00+08:00"
        )
        current = svc2.get_registration(reg["registration_id"])
        self.assertEqual(current["status"], "under_review")
        self.assertEqual(current["version"], 2)
        self.assertEqual(events_before, svc2.export_events())

    def test_expired_row_does_not_block_same_party_reregistration(self):
        old = payload(
            start="2026-09-16T09:00:00+08:00",
            end="2026-09-16T09:30:00+08:00",
            expires="2026-09-16T10:00:00+08:00",
        )
        first = self.svc.create_registration(old, "old")
        second = self.svc.create_registration(payload(), "new")
        self.assertEqual(self.svc.get_registration(first["registration_id"])["status"], "expired")
        self.assertEqual(second["status"], "submitted")

    def test_numeric_contract_rejects_bool_string_and_nonfinite(self):
        bad_values = [True, "5", float("inf"), float("nan")]
        for index, bad in enumerate(bad_values):
            candidate = payload(party_id=f"bad-{index}")
            candidate["hard_constraints"]["max_walking_minutes"] = bad
            with self.subTest(value=repr(bad)), self.assertRaises(ValidationError):
                self.svc.create_registration(candidate, f"bad-key-{index}")

        candidate = payload(party_id="bad-transfer")
        candidate["hard_constraints"]["max_transfers"] = True
        with self.assertRaises(ValidationError):
            self.svc.create_registration(candidate, "bad-transfer")

        candidate = payload(party_id="large-int")
        candidate["hard_constraints"]["max_cost_cny"] = 10**1000
        created = self.svc.create_registration(candidate, "large-int")
        self.assertEqual(created["hard_constraints"]["max_cost_cny"], 10**1000)

    def test_expected_version_rejects_boolean(self):
        reg = self.svc.create_registration(payload(), "k")
        with self.assertRaises(ValidationError):
            self.svc.update_registration(reg["registration_id"], True, {"party_size": 3})


if __name__ == "__main__":
    unittest.main()
