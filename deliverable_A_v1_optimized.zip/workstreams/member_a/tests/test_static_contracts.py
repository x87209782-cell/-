from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class StaticContractTests(unittest.TestCase):
    def test_ui_has_text_and_card_variants_and_mobile_breakpoint(self):
        html = (ROOT / "app/static/index.html").read_text("utf-8")
        css = (ROOT / "app/static/styles.css").read_text("utf-8")
        js = (ROOT / "app/static/app.js").read_text("utf-8")
        self.assertIn("行动卡", html)
        self.assertIn("纯文本", html)
        self.assertIn("@media (max-width: 600px)", css)
        self.assertIn("response_discarded", js)
        self.assertIn("version!==state.inputVersion", js)
        self.assertIn("Invalidate an in-flight response immediately", js)
        self.assertIn("state.inputVersion+=1", js)
        self.assertIn("registration_submitted", js)

    def test_ui_event_allowlist_avoids_message_and_destination(self):
        main = (ROOT / "app/main.py").read_text("utf-8")
        self.assertIn("Explicit allowlist", main)
        self.assertNotIn('"message",\n    "destination_id"', main)


if __name__ == "__main__":
    unittest.main()
