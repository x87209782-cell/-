from __future__ import annotations

import json
import unittest
from pathlib import Path

from adapters.assist import AssistAdapterError, MockAssistAdapter, _validate_response_correlation
from app.version_guard import should_accept_response

ROOT = Path(__file__).resolve().parents[1]


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.adapter = MockAssistAdapter()
        self.req = json.loads((ROOT / "fixtures" / "trip_request.example.json").read_text("utf-8"))

    def test_feasible_fixture_preserves_request_version(self):
        self.req["input_version"] = 7
        result = self.adapter.assist(self.req)
        self.assertEqual(result["decision_status"], "feasible")
        self.assertEqual(result["input_version"], 7)
        self.assertEqual(result["plan_version"], 7)
        self.assertEqual(result["mode"], "mock")

    def test_all_nonfeasible_states_have_no_cards(self):
        cases = {
            "【补问】": "needs_input",
            "【无方案】": "no_feasible_plan",
            "【证据不足】": "insufficient_evidence",
            "【超范围】": "out_of_scope",
            "【错误】": "error",
        }
        for marker, status in cases.items():
            req = dict(self.req)
            req["message"] = marker
            result = self.adapter.assist(req)
            self.assertEqual(result["decision_status"], status)
            self.assertEqual(result["cards"], [])

    def test_stale_response_guard(self):
        self.assertFalse(should_accept_response(2, {"input_version": 1}))
        self.assertTrue(should_accept_response(2, {"input_version": 2}))

    def test_response_correlation_rejects_wrong_request(self):
        result = self.adapter.assist(self.req)
        result["request_id"] = "00000000-0000-4000-8000-000000000000"
        with self.assertRaises(AssistAdapterError) as caught:
            _validate_response_correlation(self.req, result)
        self.assertEqual(caught.exception.code, "response_correlation")


if __name__ == "__main__":
    unittest.main()
