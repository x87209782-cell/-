from __future__ import annotations
from copy import deepcopy


def payload(
    *,
    party_id: str = "party-1",
    party_size: int = 2,
    destination_id: str = "claude6:Z4",
    start: str = "2026-09-16T23:20:00+08:00",
    end: str = "2026-09-16T23:50:00+08:00",
    expires: str = "2026-09-17T00:10:00+08:00",
    wheelchair=None,
    mode: str = "mock",
):
    return {
        "session_id": "session-test",
        "party_id": party_id,
        "station_id": "BJN",
        "destination_id": destination_id,
        "ready_window_start": start,
        "ready_window_end": end,
        "party_size": party_size,
        "hard_constraints": {
            "max_walking_minutes": 5,
            "max_transfers": None,
            "latest_arrival_at": None,
            "max_cost_cny": None,
            "wheelchair_required": wheelchair,
        },
        "consent_to_register": True,
        "expires_at": expires,
        "mode": mode,
    }
