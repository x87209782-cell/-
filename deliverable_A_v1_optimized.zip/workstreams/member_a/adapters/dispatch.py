from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any


class MockDispatchAdapter:
    """Presentation-only dispatch fixture; intentionally contains no optimization logic."""

    def preview(self, aggregation: dict[str, Any]) -> dict[str, Any]:
        total = sum(group["party_size_total"] for group in aggregation.get("groups", []))
        return {
            "schema_version": "member-a-dispatch-mock/1.0",
            "mode": "mock",
            "source_snapshot_id": aggregation.get("snapshot_id"),
            "plan_version": 1,
            "solver_status": "mock_not_solved",
            "generated_at": datetime.now(timezone(timedelta(hours=8))).replace(microsecond=0).isoformat(),
            "draft": [],
            "unserved": [
                {
                    "group_id": group["group_id"],
                    "party_size": group["party_size_total"],
                    "reason": "队长调度 API 尚未接入；本适配器不计算车辆分配。",
                }
                for group in aggregation.get("groups", [])
            ],
            "total_registered_people": total,
            "total_unserved_people": total,
            "warnings": ["模拟调度展示，不代表车辆已安排或已到场。"],
        }
