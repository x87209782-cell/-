from __future__ import annotations

import copy
import json
import os
import socket
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Protocol

try:
    from jsonschema import Draft202012Validator, FormatChecker
except Exception:  # standalone fallback
    Draft202012Validator = None
    FormatChecker = None

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"


class AssistAdapterError(Exception):
    def __init__(self, message: str, code: str = "adapter_error", status_code: int = 502):
        super().__init__(message)
        self.code = code
        self.status_code = status_code


class AssistAdapter(Protocol):
    def assist(self, trip_request: dict[str, Any]) -> dict[str, Any]: ...


def _validate(schema_name: str, payload: dict[str, Any]) -> None:
    if Draft202012Validator is None:
        return
    schema = json.loads((FIXTURES / "contracts" / schema_name).read_text("utf-8"))
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(payload), key=lambda e: list(e.path))
    if errors:
        detail = "; ".join(e.message for e in errors[:4])
        raise AssistAdapterError(f"contract validation failed: {detail}", "contract_validation", 500)


def _validate_response_correlation(
    request: dict[str, Any], result: dict[str, Any]
) -> None:
    """Reject a valid-shaped response that belongs to another request."""
    if not isinstance(result, dict):
        raise AssistAdapterError("assist response must be a JSON object", "contract_validation", 502)
    mismatched = [
        field
        for field in ("request_id", "session_id", "input_version")
        if result.get(field) != request.get(field)
    ]
    if mismatched:
        raise AssistAdapterError(
            f"assist response correlation mismatch: {', '.join(mismatched)}",
            "response_correlation",
            502,
        )


class MockAssistAdapter:
    """Contract fixture adapter only. It does not infer routes or diagnose transport."""

    def __init__(self, fixtures_dir: str | Path = FIXTURES):
        self.fixtures_dir = Path(fixtures_dir)

    def _select_fixture(self, message: str) -> str:
        markers = {
            "【补问】": "decision_needs_input.json",
            "【无方案】": "decision_no_feasible.json",
            "【证据不足】": "decision_insufficient.json",
            "【超范围】": "decision_out_of_scope.json",
            "【错误】": "decision_error.json",
        }
        for marker, name in markers.items():
            if marker in message:
                return name
        return "decision_feasible.json"

    def assist(self, trip_request: dict[str, Any]) -> dict[str, Any]:
        _validate("trip_request.schema.json", trip_request)
        fixture_name = self._select_fixture(str(trip_request.get("message", "")))
        result = json.loads((self.fixtures_dir / fixture_name).read_text("utf-8"))
        result = copy.deepcopy(result)
        now = datetime.now(timezone(timedelta(hours=8))).replace(microsecond=0)
        result["request_id"] = trip_request["request_id"]
        result["session_id"] = trip_request["session_id"]
        result["input_version"] = trip_request["input_version"]
        result["plan_version"] = trip_request["input_version"]
        result["mode"] = "mock"
        result["data_version"] = "member-a-mock-v1"
        result["generated_at"] = now.isoformat()
        if result["decision_status"] == "feasible":
            result["valid_until"] = (now + timedelta(minutes=15)).isoformat()
            for card in result["cards"]:
                for step in card["steps"]:
                    if step["action_by"] is not None:
                        step["action_by"] = (now + timedelta(minutes=15)).isoformat()
                if card["arrival_at"] is not None:
                    card["arrival_at"] = (now + timedelta(minutes=45)).isoformat()
        else:
            result["valid_until"] = None
        if "仅供接口联调，不是实际出行建议。" not in result["warnings"]:
            result["warnings"].append("仅供接口联调，不是实际出行建议。")
        _validate("decision_result.schema.json", result)
        _validate_response_correlation(trip_request, result)
        return result


class HttpAssistAdapter:
    def __init__(self, base_url: str, timeout_seconds: float = 8.0):
        base = base_url.rstrip("/")
        if not base:
            raise ValueError("base_url is required for http adapter")
        self.url = base + "/v1/assist"
        self.timeout_seconds = timeout_seconds

    def assist(self, trip_request: dict[str, Any]) -> dict[str, Any]:
        _validate("trip_request.schema.json", trip_request)
        req = urllib.request.Request(
            self.url,
            data=json.dumps(trip_request, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                body = resp.read().decode("utf-8")
                result = json.loads(body)
        except urllib.error.HTTPError as exc:
            if exc.code == 409:
                raise AssistAdapterError("input version conflict", "version_conflict", 409) from exc
            if 500 <= exc.code <= 599:
                raise AssistAdapterError("leader assist service 5xx", "upstream_5xx", 502) from exc
            raise AssistAdapterError(f"leader assist service HTTP {exc.code}", "upstream_http", 502) from exc
        except (TimeoutError, socket.timeout) as exc:
            raise AssistAdapterError("leader assist service timeout", "timeout", 504) from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", None)
            if isinstance(reason, socket.timeout):
                raise AssistAdapterError("leader assist service timeout", "timeout", 504) from exc
            raise AssistAdapterError("leader assist service unavailable", "upstream_unavailable", 502) from exc
        except json.JSONDecodeError as exc:
            raise AssistAdapterError("leader assist service returned invalid JSON", "invalid_json", 502) from exc
        _validate("decision_result.schema.json", result)
        _validate_response_correlation(trip_request, result)
        return result


def build_assist_adapter() -> AssistAdapter:
    mode = os.getenv("ASSIST_ADAPTER", "mock").strip().lower()
    if mode == "mock":
        return MockAssistAdapter()
    if mode == "http":
        return HttpAssistAdapter(
            os.getenv("ASSIST_BASE_URL", ""),
            float(os.getenv("ASSIST_TIMEOUT_SECONDS", "8")),
        )
    raise ValueError("ASSIST_ADAPTER must be mock or http")
