# UI 匿名事件日志

字段遵守共同合同：

`event_id, session_pseudonym, variant, task_id, event_type, client_timestamp, input_version, plan_version, duration_ms, error_code, mode`

P0覆盖：`request_sent, response_displayed, response_discarded, card_opened, conditions_changed, registration_submitted, registration_cancelled, task_finished`。

隐私边界：默认不写用户原话、姓名、手机号、身份证、精确家庭地址；目的地仅在登记数据库按合同保存标准 `destination_id`，UI实验日志不保存。
