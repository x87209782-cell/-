# 开工后四小时任务清单（P0）

状态基准：2026-09-16，本目录为队员A唯一写入区。

- [x] 读取共同合同、A任务书、contracts/与只读参考平台材料。
- [x] 检查运行环境：Python 3.13；FastAPI/uvicorn/jsonschema 可用；Streamlit 不可用。
- [x] 建立 `workstreams/member_a/` 独立目录，不修改共同合同和 reference/。
- [x] 画出旅客页面流、登记状态机、旧响应丢弃时序与接线清单。
- [x] 实现 SQLite 登记模块：幂等、同行组唯一、expected_version、取消、过期、事件、精确条件聚合。
- [x] 实现 mock/http 两种 assist adapter，配置切换不改变页面业务逻辑。
- [x] 实现 P0 双端 Web：问询、补问/状态、card/text 等信息切换、条件变化、主动登记、取消、管理端聚合与调度 mock。
- [x] 实现统一匿名事件日志与 JSONL 导出。
- [x] 编写固定可靠性故障回放与 append-only 实验基线。
- [ ] 与队长真实 `/v1/assist` 联调（当前未提供 BASE_URL/服务）。
- [ ] 管理端真实 `/v1/dispatch/preview` 联调（共同合同明确本期由队长后续定义；当前使用独立 mock）。
- [x] 360px Chromium 布局/交互检查并归档截图；真实 localhost 浏览器导航受环境策略限制，后端另用 HTTP smoke test 验证。
