# RQ1 UI 两版本

`card` 与 `text` 两个版本必须消费同一个 `DecisionResult`，不增加或删减语义字段。

- card：用步骤、行动截止、步行/换乘、费用、到达时间、limitations、warnings 分块展示。
- text：把同一字段序列化为连续文本段落。
- 两版都显示 `decision_status`、mode、data_version、generated_at、valid_until、证据ID/来源ID与局限。
- 技术 ID 默认折叠；实验日志写 `variant=text|card`。
- 用户条件变化后，两版都立即将上一方案标为“已失效/重算中”，不能让旧卡继续呈现为有效。
