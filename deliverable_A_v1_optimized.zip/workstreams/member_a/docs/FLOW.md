# P0 页面流、状态图与接线

## 旅客流程

```mermaid
flowchart TD
  A[输入自然语言 + 简短表单] --> B[POST /api/assist]
  B --> C{DecisionResult}
  C -->|needs_input| D[展示补问]
  C -->|feasible| E[同一结果可切换 card/text]
  C -->|no_feasible_plan| F[明确当前服务集合下无可行方案]
  C -->|insufficient_evidence| G[说明信息不足并提示核实]
  C -->|out_of_scope| H[说明超范围]
  C -->|error/HTTP异常| I[技术错误/重试]
  D --> A
  E --> J[条件变化: input_version +1, 旧卡立即失效]
  J --> B
  E --> K{用户明确同意登记?}
  K -->|否| L[仅咨询，不登记]
  K -->|是| M[创建 Registration]
  M --> N[我的需求: submitted / under_review / simulated_confirmed]
  N --> O[取消或过期]
```

## 登记状态机

```mermaid
stateDiagram-v2
  [*] --> submitted
  submitted --> under_review
  under_review --> simulated_confirmed
  simulated_confirmed --> completed
  submitted --> cancelled
  under_review --> cancelled
  simulated_confirmed --> cancelled
  submitted --> expired
  under_review --> expired
  simulated_confirmed --> expired
  cancelled --> [*]
  expired --> [*]
  completed --> [*]
```

终态不可复活。`simulated_confirmed` 仅用于 `mock/scenario/historical_demo`；本模块不实现 verified_service 的真实确认。

## 乱序响应保护

```mermaid
sequenceDiagram
  participant U as UI
  participant A as Assist Adapter
  U->>A: input_version=1
  U->>U: 条件改变，立即标记旧卡过期
  U->>A: input_version=2
  A-->>U: v2 先返回 -> 接受
  A-->>U: v1 后返回 -> response_discarded
```

客户端只展示匹配当前 `input_version` 的响应；`plan_version` 由服务端结果提供，不能用到达顺序替代。

## 接线清单

- `ASSIST_ADAPTER=mock|http`：默认 `mock`。
- `ASSIST_BASE_URL`：http 模式下队长服务根地址，调用 `/v1/assist`。
- `POST /api/assist`：A层只转发/展示，不做路线推断。
- `registration.RegistrationService`：队长可直接导入挂载。
- `GET /api/admin/aggregation`：导出共同合同形状的聚合结果。
- `GET /api/admin/events`：登记审计事件。
- `GET /api/ui-events`：匿名交互日志；默认不记录用户原话和精确目的地。
- `GET /api/dispatch/preview`：P0 独立 mock，只展示草案/未服务/求解状态；不做车辆优化。
