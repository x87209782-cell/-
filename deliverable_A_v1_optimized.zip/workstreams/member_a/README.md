# 夜归有接 · 队员A P0

版本：`member-a-p0/0.1.1`（2026-09-16）

本目录只实现队员A职责：旅客/管理双端、行动卡/纯文本等信息界面、mock/http 接线、需求登记状态机、可靠性回放与匿名交互日志。**不包含 LLM 编排、路线求解、车辆优化、交通事实知识库或真人访谈。**

## 已实测环境

- Python 3.13.5
- FastAPI 0.128.2
- Uvicorn 0.48.0
- jsonschema 4.26.0
- Chromium（仅用于 360px 布局检查；本运行环境策略阻止浏览器直接导航 localhost，因此 API 另用 curl 做真实 HTTP smoke test）

## 启动

解压后从 `workstreams/member_a/` 运行：

```bash
python -m pip install -r requirements.txt
ASSIST_ADAPTER=mock python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

浏览器打开 `http://127.0.0.1:8000/`。首屏会显示 `MOCK 模式`；mock 行动卡中的地点与时刻均为接口联调虚构数据，不是实际出行建议。

接队长 `/v1/assist` 时只改配置，不改页面业务逻辑：

```bash
ASSIST_ADAPTER=http \
ASSIST_BASE_URL=http://127.0.0.1:9000 \
ASSIST_TIMEOUT_SECONDS=8 \
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

HTTP adapter 调用 `${ASSIST_BASE_URL}/v1/assist`，分别区分 409、超时、5xx、无服务和合同校验失败。

## 运行测试

```bash
PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -v
PYTHONPATH=. python experiments/reliability_replay.py
```

本次实际结果：19 个单元/静态合同测试全部通过；固定可靠性回放 9/9 断言通过；health、assist、登记、聚合、取消 HTTP 冒烟链路全部返回 200。完整输出见 `results/unittest_output.txt` 与 `results/fixed_reliability_result.json`。

## 登记模块给队长的导入方式

```python
from registration import RegistrationService

svc = RegistrationService("/path/to/registrations.sqlite3")
reg = svc.create_registration(payload, idempotency_key="client-retry-key")
reg = svc.update_registration(reg["registration_id"], reg["version"], {"status": "under_review"})
groups = svc.export_active_groups("2026-09-16T23:40:00+08:00")
events = svc.export_events(0)
```

共同合同要求的六个函数也提供了模块级包装器；先用 `configure_default(db_path)` 配置数据库即可。

## P0 页面与接口

旅客端覆盖：问询、needs_input/feasible/no_feasible_plan/insufficient_evidence/out_of_scope/error、行动卡/纯文本切换、条件变化后 `input_version` 增加和旧响应丢弃、主动登记、我的需求与取消。

`0.1.1` 加固：条件一变化即提升 `input_version`，在下一次提交前也能拒绝在途旧响应；HTTP assist 响应必须与原请求的 `request_id/session_id/input_version` 一致；过期与聚合快照在同一事务内完成，过期同行组不会阻塞重新登记；数值字段与版本号拒绝布尔、字符串和非有限数。

管理端覆盖：有效需求人数、精确条件分组、取消/过期排除、匿名登记与版本追溯、独立 dispatch mock。dispatch mock 始终显示 `mock_not_solved`，不会在 A 端自行计算车辆分配。

主要本地 API：

- `POST /api/assist`
- `POST /api/registrations`
- `PATCH /api/registrations/{id}`
- `POST /api/registrations/{id}/cancel`
- `GET /api/admin/aggregation`
- `GET /api/admin/events`
- `GET /api/dispatch/preview`
- `POST/GET /api/ui-events`

## 结果证据

- `results/aggregation_example.json`：一次真实 P0 smoke test 导出的 AggregationResult。
- `results/registration_events_example.json`：登记审计事件。
- `results/ui_events_example.jsonl`：通过实际 API 写入并导出的匿名交互事件日志。
- `results/aggregation_after_cancel.json`：取消后 groups 为空、`excluded_counts.cancelled=1`。
- `results/mobile_360_result.png` / `mobile_360_admin.png`：360px 浏览器布局检查。
- `results/mobile_360_check.md`：检查方法与限制。

## 数据与隐私边界

UI 事件采用字段 allowlist，默认不记录用户原话、姓名、电话、身份证或精确家庭地址。登记数据库仅保存共同合同所需标准字段。匿名多设备无法完全去重；当前只保证同 `party_id` 在本系统最多一条非终态登记。

## 已知接口问题

见 `contract_change_request.md`：共同合同的 `AggregationResult` 只有一个结果级 `mode`，无法无歧义表达多个 mode 同时存在的有效登记。A 未擅自改合同；当前混合 mode 聚合会 fail-closed。
