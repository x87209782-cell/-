# METHODS

## 研究问题 A-RQ1：行动卡 vs 纯文本

实现 `card` 与 `text` 两种可切换界面，二者消费**同一个 DecisionResult**。对照只改变信息组织方式，不改变后端建议、证据、字段或方案数量。两版都显示决策状态、模式、数据版本、生成/有效时间、方案版本、步骤、地点、行动截止、步行/换乘、费用、到达时间、来源ID、限制、证据ID与 warnings。

A 只实现组件与统一日志；真人试用、顺序平衡、告知同意和统计由 B 负责。本轮没有真人用户实验，因此不能声称行动卡提高了正确率或速度。可由 B 统计：是否能正确复述下一步、完成耗时、错误次数、操作负担；否定条件沿任务书执行。

## 研究问题 A-RQ2：可靠登记状态管理

### 完整模块

`registration/service.py` 使用 SQLite + `BEGIN IMMEDIATE` 事务。核心机制：

1. **幂等**：`idempotency_key` 唯一，并保存创建 payload 的 canonical SHA-256；同 key 同 payload 返回原记录，同 key 不同 payload 冲突。
2. **同行组去重**：SQLite partial unique index 保证同 `party_id` 最多一条 `submitted/under_review/simulated_confirmed`。
3. **乐观并发**：更新必须匹配 `expected_version`；成功后版本 +1，旧版本更新返回 `version_conflict`。
4. **状态机**：`submitted → under_review → simulated_confirmed → completed`，前三态可 `cancelled/expired`；终态不可复活；`verified_service` 禁止进入 `simulated_confirmed`。
5. **事件一致性**：记录变更与 RegistrationEvent 在同一数据库事务提交。
6. **过期**：显式 `expire_registrations(now)`，且 `export_active_groups(now)` 会再次执行过期检查，避免依赖定时器。
7. **精确聚合**：仅按 station、destination、精确时间窗、mode、完整 hard_constraints 相同聚合；canonical JSON 保留 `null` 与 `false` 差异。
8. **人数守恒**：组人数为当前有效记录人数直接求和；终态和过期记录不参加，不生成默认人数。
9. **重启一致性**：SQLite WAL 持久化；新建 `RegistrationService` 后记录/事件仍一致。

### 实验基线

`experiments/append_only_baseline.py` 是明确标记的故障机制基线，只用于 A-RQ2 对照：追加记录、无幂等、无版本校验、聚合不检查过期、忽略硬约束差异。它不是第二套生产平台。

### 固定故障回放

`experiments/reliability_replay.py` 在执行前写死正确性断言，覆盖：

- 相同提交重试10次只计1组；
- 同 key 不同 payload 拒绝；
- 同 expected_version 的两次更新只允许一项成功；
- 取消重试不复活；
- 过期不聚合；
- 不同硬约束不合并；
- 需求人数守恒；
- 旧决策响应丢弃；
- 重启后状态与事件一致。

本轮完整模块 9/9 通过。基线中相同 2 人登记重试10次被错误累计为20人，并观察到过期残留、最后写覆盖和硬约束混合。该实验是**合成可靠性测试，不代表真实并发吞吐或生产承载能力**。

## UI 版本与乱序响应

浏览器维护 `session_id` 和 `input_version`。首次有效发送为 v1；提交内容 fingerprint 改变时 v+1 并生成新的 request_id；原样重试复用 request_id/version。条件变化后旧结果立即标记失效。返回结果只有 `result.input_version === current input_version` 才可展示，否则记录 `response_discarded`。

`0.1.1` 将版本提升前移到条件变化事件本身，而不是等待下一次发送，因此在途旧响应也不能覆盖已改变的输入。HTTP adapter 还会校验返回的 `request_id/session_id/input_version` 与请求一致，避免“结构合法但串请求”的结果进入 UI。

## 日志与隐私

UI 日志字段只允许共同合同规定的匿名字段。服务端用 allowlist 重建事件对象，额外字段（包括 message/destination）不会被写入。登记审计日志保存状态、版本和变更字段，不保存界面原话。

## 360px 检查

后端 API 用真实 HTTP/curl smoke test 验证。运行环境的 Chromium 被策略禁止直接导航 localhost，因此浏览器布局检查使用同一 HTML/CSS/JS + fetch stub；viewport 360×800，实际测得 `document.scrollWidth=360`，无横向溢出，并自动走过问询、card/text、登记、管理聚合。该检查不是移动真机测试或真人可用性实验。

## P1 未执行项

任务书要求的 ≥200 条固定随机种子合成序列属于 P1。本 P0 不把该目标写成已完成结果；后续应先定义冲突分布和断言，再比较完整模块/基线的重复人数、过期残留、丢失更新、非法状态、耗时分布。
