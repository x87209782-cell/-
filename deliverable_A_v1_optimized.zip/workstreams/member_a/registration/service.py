from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Callable, Iterable

SCHEMA_VERSION = "1.0"
DB_SCHEMA_VERSION = 1
ACTIVE_STATUSES = {"submitted", "under_review", "simulated_confirmed"}
TERMINAL_STATUSES = {"cancelled", "expired", "completed"}
ALL_STATUSES = ACTIVE_STATUSES | TERMINAL_STATUSES
ALLOWED_TRANSITIONS = {
    "submitted": {"under_review", "cancelled", "expired"},
    "under_review": {"simulated_confirmed", "cancelled", "expired"},
    "simulated_confirmed": {"completed", "cancelled", "expired"},
    "cancelled": set(),
    "expired": set(),
    "completed": set(),
}
MODES = {"mock", "historical_demo", "scenario", "verified_service"}


class RegistrationError(Exception):
    code = "registration_error"


class ValidationError(RegistrationError):
    code = "validation_error"


class ConflictError(RegistrationError):
    code = "conflict"


class NotFoundError(RegistrationError):
    code = "not_found"


class VersionConflictError(ConflictError):
    code = "version_conflict"


class IdempotencyConflictError(ConflictError):
    code = "idempotency_conflict"


class PartyConflictError(ConflictError):
    code = "party_conflict"


class AggregationModeConflictError(ConflictError):
    code = "aggregation_mode_conflict"


class InvalidTransitionError(ConflictError):
    code = "invalid_transition"


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _payload_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _parse_iso(value: str, field: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValidationError(f"{field} must be a non-empty ISO 8601 string")
    try:
        dt = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValidationError(f"{field} must be valid ISO 8601") from exc
    if dt.tzinfo is None:
        raise ValidationError(f"{field} must include timezone offset")
    if dt.utcoffset() != timedelta(hours=8):
        raise ValidationError(f"{field} must use +08:00")
    return dt


def _iso_now() -> str:
    return datetime.now(timezone(timedelta(hours=8))).replace(microsecond=0).isoformat()


def _ensure_hard_constraints(value: Any) -> dict[str, Any]:
    required = {
        "max_walking_minutes",
        "max_transfers",
        "latest_arrival_at",
        "max_cost_cny",
        "wheelchair_required",
    }
    if not isinstance(value, dict) or set(value.keys()) != required:
        raise ValidationError("hard_constraints must contain the five contract fields exactly")
    for field in ("max_walking_minutes", "max_cost_cny"):
        item = value[field]
        if item is not None and (
            isinstance(item, bool)
            or not isinstance(item, (int, float))
            or (isinstance(item, float) and not math.isfinite(item))
            or item < 0
        ):
            raise ValidationError(f"{field} must be a finite number >= 0 or null")
    if value["max_transfers"] is not None and (
        isinstance(value["max_transfers"], bool)
        or not isinstance(value["max_transfers"], int)
        or value["max_transfers"] < 0
    ):
        raise ValidationError("max_transfers must be integer >= 0 or null")
    if value["wheelchair_required"] is not None and not isinstance(value["wheelchair_required"], bool):
        raise ValidationError("wheelchair_required must be boolean or null")
    if value["latest_arrival_at"] is not None:
        _parse_iso(value["latest_arrival_at"], "hard_constraints.latest_arrival_at")
    return value


def _validate_create_payload(payload: dict[str, Any]) -> dict[str, Any]:
    required = {
        "session_id",
        "party_id",
        "station_id",
        "destination_id",
        "ready_window_start",
        "ready_window_end",
        "party_size",
        "hard_constraints",
        "consent_to_register",
        "expires_at",
        "mode",
    }
    missing = sorted(required - set(payload))
    if missing:
        raise ValidationError(f"missing required fields: {', '.join(missing)}")
    if payload["consent_to_register"] is not True:
        raise ValidationError("consent_to_register must be true")
    for field in ("session_id", "party_id", "station_id", "destination_id"):
        if not isinstance(payload[field], str) or not payload[field].strip():
            raise ValidationError(f"{field} must be non-empty")
    if payload["station_id"] != "BJN":
        raise ValidationError("P0 only supports station_id=BJN")
    if not isinstance(payload["party_size"], int) or isinstance(payload["party_size"], bool) or payload["party_size"] < 1:
        raise ValidationError("party_size must be a positive integer")
    if payload["mode"] not in MODES:
        raise ValidationError("unsupported mode")
    start = _parse_iso(payload["ready_window_start"], "ready_window_start")
    end = _parse_iso(payload["ready_window_end"], "ready_window_end")
    expires = _parse_iso(payload["expires_at"], "expires_at")
    if end <= start:
        raise ValidationError("ready_window_end must be after ready_window_start")
    if expires <= start:
        raise ValidationError("expires_at must be after ready_window_start")
    _ensure_hard_constraints(payload["hard_constraints"])
    return payload


def _row_to_registration(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "registration_id": row["registration_id"],
        "session_id": row["session_id"],
        "party_id": row["party_id"],
        "station_id": row["station_id"],
        "destination_id": row["destination_id"],
        "ready_window_start": row["ready_window_start"],
        "ready_window_end": row["ready_window_end"],
        "party_size": row["party_size"],
        "hard_constraints": json.loads(row["hard_constraints_json"]),
        "consent_to_register": bool(row["consent_to_register"]),
        "expires_at": row["expires_at"],
        "mode": row["mode"],
        "status": row["status"],
        "version": row["version"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


@dataclass
class RegistrationService:
    db_path: str | Path
    now_provider: Callable[[], str] = field(default=_iso_now, repr=False)

    def __post_init__(self) -> None:
        self.db_path = str(self.db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._migrate()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def _migrate(self) -> None:
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS registrations(
                    registration_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    party_id TEXT NOT NULL,
                    station_id TEXT NOT NULL,
                    destination_id TEXT NOT NULL,
                    ready_window_start TEXT NOT NULL,
                    ready_window_end TEXT NOT NULL,
                    party_size INTEGER NOT NULL CHECK(party_size > 0),
                    hard_constraints_json TEXT NOT NULL,
                    consent_to_register INTEGER NOT NULL CHECK(consent_to_register = 1),
                    expires_at TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    status TEXT NOT NULL,
                    version INTEGER NOT NULL CHECK(version >= 1),
                    idempotency_key TEXT NOT NULL UNIQUE,
                    create_payload_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS ux_active_party
                ON registrations(party_id)
                WHERE status IN ('submitted','under_review','simulated_confirmed');
                CREATE TABLE IF NOT EXISTS registration_events(
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    registration_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    from_status TEXT,
                    to_status TEXT,
                    version INTEGER NOT NULL,
                    occurred_at TEXT NOT NULL,
                    details_json TEXT NOT NULL,
                    FOREIGN KEY(registration_id) REFERENCES registrations(registration_id)
                );
                CREATE INDEX IF NOT EXISTS ix_events_registration
                ON registration_events(registration_id, event_id);
                """
            )
            con.execute(
                "INSERT INTO meta(key,value) VALUES('db_schema_version',?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(DB_SCHEMA_VERSION),),
            )
            con.commit()

    def _insert_event(
        self,
        con: sqlite3.Connection,
        registration_id: str,
        event_type: str,
        version: int,
        *,
        from_status: str | None,
        to_status: str | None,
        details: dict[str, Any] | None = None,
        occurred_at: str | None = None,
    ) -> None:
        con.execute(
            """INSERT INTO registration_events(
                registration_id,event_type,from_status,to_status,version,occurred_at,details_json
            ) VALUES(?,?,?,?,?,?,?)""",
            (
                registration_id,
                event_type,
                from_status,
                to_status,
                version,
                occurred_at or _iso_now(),
                _canonical_json(details or {}),
            ),
        )

    def _expire_in_transaction(
        self,
        con: sqlite3.Connection,
        now_dt: datetime,
        now_iso: str,
    ) -> int:
        """Expire due rows while the caller holds a write transaction."""
        count = 0
        rows = con.execute(
            "SELECT * FROM registrations "
            "WHERE status IN ('submitted','under_review','simulated_confirmed')"
        ).fetchall()
        for row in rows:
            if _parse_iso(row["expires_at"], "expires_at") > now_dt:
                continue
            new_version = row["version"] + 1
            con.execute(
                "UPDATE registrations SET status='expired', version=?, updated_at=? "
                "WHERE registration_id=? AND version=?",
                (new_version, now_iso, row["registration_id"], row["version"]),
            )
            self._insert_event(
                con,
                row["registration_id"],
                "registration_expired",
                new_version,
                from_status=row["status"],
                to_status="expired",
                details={"expired_at_check": now_iso},
                occurred_at=now_iso,
            )
            count += 1
        return count

    def create_registration(self, payload: dict[str, Any], idempotency_key: str) -> dict[str, Any]:
        if not isinstance(idempotency_key, str) or not idempotency_key.strip():
            raise ValidationError("idempotency_key is required")
        payload = _validate_create_payload(dict(payload))
        payload_hash = _payload_hash(payload)
        now = self.now_provider()
        registration_id = str(uuid.uuid4())
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            # A stale active row must not block the party from registering again.
            self._expire_in_transaction(con, _parse_iso(now, "now"), now)
            existing = con.execute(
                "SELECT * FROM registrations WHERE idempotency_key=?", (idempotency_key,)
            ).fetchone()
            if existing:
                if existing["create_payload_hash"] != payload_hash:
                    con.rollback()
                    raise IdempotencyConflictError("same idempotency_key used with different payload")
                con.commit()
                return _row_to_registration(existing)
            active = con.execute(
                "SELECT registration_id FROM registrations WHERE party_id=? "
                "AND status IN ('submitted','under_review','simulated_confirmed')",
                (payload["party_id"],),
            ).fetchone()
            if active:
                con.rollback()
                raise PartyConflictError("party_id already has an active registration")
            try:
                con.execute(
                    """INSERT INTO registrations(
                        registration_id,session_id,party_id,station_id,destination_id,
                        ready_window_start,ready_window_end,party_size,hard_constraints_json,
                        consent_to_register,expires_at,mode,status,version,idempotency_key,
                        create_payload_hash,created_at,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        registration_id,
                        payload["session_id"],
                        payload["party_id"],
                        payload["station_id"],
                        payload["destination_id"],
                        payload["ready_window_start"],
                        payload["ready_window_end"],
                        payload["party_size"],
                        _canonical_json(payload["hard_constraints"]),
                        1,
                        payload["expires_at"],
                        payload["mode"],
                        "submitted",
                        1,
                        idempotency_key,
                        payload_hash,
                        now,
                        now,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                con.rollback()
                raise PartyConflictError("party_id already has an active registration") from exc
            self._insert_event(
                con,
                registration_id,
                "registration_created",
                1,
                from_status=None,
                to_status="submitted",
                details={"idempotency_key_hash": hashlib.sha256(idempotency_key.encode()).hexdigest()},
                occurred_at=now,
            )
            row = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
            con.commit()
            return _row_to_registration(row)

    def get_registration(self, registration_id: str) -> dict[str, Any]:
        with self._connect() as con:
            row = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
        if not row:
            raise NotFoundError("registration not found")
        return _row_to_registration(row)

    def list_registrations(self, session_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as con:
            if session_id is None:
                rows = con.execute("SELECT * FROM registrations ORDER BY created_at, registration_id").fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM registrations WHERE session_id=? ORDER BY created_at, registration_id",
                    (session_id,),
                ).fetchall()
        return [_row_to_registration(row) for row in rows]

    def update_registration(
        self,
        registration_id: str,
        expected_version: int,
        patch: dict[str, Any],
    ) -> dict[str, Any]:
        if isinstance(expected_version, bool) or not isinstance(expected_version, int) or expected_version < 1:
            raise ValidationError("expected_version must be >= 1")
        if not isinstance(patch, dict) or not patch:
            raise ValidationError("patch must be a non-empty object")
        allowed = {
            "status",
            "destination_id",
            "ready_window_start",
            "ready_window_end",
            "party_size",
            "hard_constraints",
            "expires_at",
        }
        unknown = set(patch) - allowed
        if unknown:
            raise ValidationError(f"unsupported patch fields: {', '.join(sorted(unknown))}")
        now = _iso_now()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
            if not row:
                con.rollback()
                raise NotFoundError("registration not found")
            if row["version"] != expected_version:
                con.rollback()
                raise VersionConflictError(
                    f"expected version {expected_version}, current version {row['version']}"
                )
            current = _row_to_registration(row)
            if current["status"] in TERMINAL_STATUSES:
                con.rollback()
                raise InvalidTransitionError("terminal registration cannot be updated")

            updated = dict(current)
            for key, value in patch.items():
                if key == "status":
                    if value not in ALL_STATUSES:
                        con.rollback()
                        raise ValidationError("invalid status")
                    if value != current["status"] and value not in ALLOWED_TRANSITIONS[current["status"]]:
                        con.rollback()
                        raise InvalidTransitionError(f"{current['status']} -> {value} is not allowed")
                    if value == "simulated_confirmed" and current["mode"] == "verified_service":
                        con.rollback()
                        raise InvalidTransitionError("verified_service cannot use simulated_confirmed")
                elif key == "party_size":
                    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                        con.rollback()
                        raise ValidationError("party_size must be a positive integer")
                elif key == "hard_constraints":
                    _ensure_hard_constraints(value)
                elif key in {"ready_window_start", "ready_window_end", "expires_at"}:
                    _parse_iso(value, key)
                elif key == "destination_id":
                    if not isinstance(value, str) or not value.strip():
                        con.rollback()
                        raise ValidationError("destination_id must be non-empty")
                updated[key] = value
            start = _parse_iso(updated["ready_window_start"], "ready_window_start")
            end = _parse_iso(updated["ready_window_end"], "ready_window_end")
            expires = _parse_iso(updated["expires_at"], "expires_at")
            if end <= start:
                con.rollback()
                raise ValidationError("ready_window_end must be after ready_window_start")
            if expires <= start:
                con.rollback()
                raise ValidationError("expires_at must be after ready_window_start")

            new_version = current["version"] + 1
            con.execute(
                """UPDATE registrations SET
                    destination_id=?, ready_window_start=?, ready_window_end=?, party_size=?,
                    hard_constraints_json=?, expires_at=?, status=?, version=?, updated_at=?
                    WHERE registration_id=? AND version=?""",
                (
                    updated["destination_id"],
                    updated["ready_window_start"],
                    updated["ready_window_end"],
                    updated["party_size"],
                    _canonical_json(updated["hard_constraints"]),
                    updated["expires_at"],
                    updated["status"],
                    new_version,
                    now,
                    registration_id,
                    expected_version,
                ),
            )
            self._insert_event(
                con,
                registration_id,
                "registration_updated",
                new_version,
                from_status=current["status"],
                to_status=updated["status"],
                details={"changed_fields": sorted(patch.keys())},
                occurred_at=now,
            )
            out = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
            con.commit()
            return _row_to_registration(out)

    def cancel_registration(self, registration_id: str, expected_version: int) -> dict[str, Any]:
        if isinstance(expected_version, bool) or not isinstance(expected_version, int) or expected_version < 1:
            raise ValidationError("expected_version must be >= 1")
        now = _iso_now()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
            if not row:
                con.rollback()
                raise NotFoundError("registration not found")
            current = _row_to_registration(row)
            if current["status"] == "cancelled":
                con.commit()
                return current
            if current["version"] != expected_version:
                con.rollback()
                raise VersionConflictError(
                    f"expected version {expected_version}, current version {current['version']}"
                )
            if current["status"] in {"expired", "completed"}:
                con.rollback()
                raise InvalidTransitionError(f"cannot cancel terminal state {current['status']}")
            new_version = current["version"] + 1
            con.execute(
                "UPDATE registrations SET status='cancelled', version=?, updated_at=? "
                "WHERE registration_id=? AND version=?",
                (new_version, now, registration_id, expected_version),
            )
            self._insert_event(
                con,
                registration_id,
                "registration_cancelled",
                new_version,
                from_status=current["status"],
                to_status="cancelled",
                details={},
                occurred_at=now,
            )
            out = con.execute(
                "SELECT * FROM registrations WHERE registration_id=?", (registration_id,)
            ).fetchone()
            con.commit()
            return _row_to_registration(out)

    def expire_registrations(self, now: str) -> int:
        now_dt = _parse_iso(now, "now")
        now_iso = now_dt.replace(microsecond=0).isoformat()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            count = self._expire_in_transaction(con, now_dt, now_iso)
            con.commit()
        return count

    def export_active_groups(self, now: str) -> dict[str, Any]:
        now_dt = _parse_iso(now, "now")
        now_iso = now_dt.replace(microsecond=0).isoformat()
        with self._connect() as con:
            # Expiry and snapshot read are one transaction, so a concurrent
            # create/update cannot slip between the two operations.
            con.execute("BEGIN IMMEDIATE")
            self._expire_in_transaction(con, now_dt, now_iso)
            rows = con.execute("SELECT * FROM registrations ORDER BY registration_id").fetchall()
            con.commit()
        active: list[dict[str, Any]] = []
        excluded_counts: dict[str, int] = {
            "cancelled": 0,
            "expired": 0,
            "completed": 0,
        }
        for row in rows:
            reg = _row_to_registration(row)
            if reg["status"] in ACTIVE_STATUSES and _parse_iso(reg["expires_at"], "expires_at") > now_dt:
                active.append(reg)
            else:
                excluded_counts[reg["status"]] = excluded_counts.get(reg["status"], 0) + 1

        buckets: dict[tuple[str, ...], list[dict[str, Any]]] = {}
        for reg in active:
            key = (
                reg["station_id"],
                reg["destination_id"],
                reg["ready_window_start"],
                reg["ready_window_end"],
                reg["mode"],
                _canonical_json(reg["hard_constraints"]),
            )
            buckets.setdefault(key, []).append(reg)
        groups: list[dict[str, Any]] = []
        for key, regs in sorted(buckets.items(), key=lambda item: item[0]):
            raw = "|".join(key)
            group_id = "grp-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
            groups.append(
                {
                    "group_id": group_id,
                    "station_id": key[0],
                    "destination_id": key[1],
                    "ready_window_start": key[2],
                    "ready_window_end": key[3],
                    "party_size_total": sum(r["party_size"] for r in regs),
                    "registration_ids": [r["registration_id"] for r in regs],
                    "hard_constraints": json.loads(key[5]),
                    "source_registration_versions": [
                        {"registration_id": r["registration_id"], "version": r["version"]}
                        for r in regs
                    ],
                }
            )
        active_modes = {r["mode"] for r in active}
        if len(active_modes) > 1:
            raise AggregationModeConflictError(
                "shared contract has one result-level mode; mixed active modes require separate snapshots or a contract change"
            )
        return {
            "schema_version": SCHEMA_VERSION,
            "snapshot_id": str(uuid.uuid4()),
            "as_of": now_dt.replace(microsecond=0).isoformat(),
            "mode": next(iter(active_modes), "mock"),
            "groups": groups,
            "excluded_counts": excluded_counts,
        }

    def export_events(self, since_event_id: int = 0) -> list[dict[str, Any]]:
        if isinstance(since_event_id, bool) or not isinstance(since_event_id, int) or since_event_id < 0:
            raise ValidationError("since_event_id must be >= 0")
        with self._connect() as con:
            rows = con.execute(
                "SELECT * FROM registration_events WHERE event_id>? ORDER BY event_id",
                (since_event_id,),
            ).fetchall()
        return [
            {
                "event_id": row["event_id"],
                "registration_id": row["registration_id"],
                "event_type": row["event_type"],
                "from_status": row["from_status"],
                "to_status": row["to_status"],
                "version": row["version"],
                "occurred_at": row["occurred_at"],
                "details": json.loads(row["details_json"]),
            }
            for row in rows
        ]


_default_service: RegistrationService | None = None


def configure_default(db_path: str | Path) -> RegistrationService:
    global _default_service
    _default_service = RegistrationService(db_path)
    return _default_service


def _service() -> RegistrationService:
    if _default_service is None:
        raise RuntimeError("registration default service not configured")
    return _default_service


def create_registration(payload: dict[str, Any], idempotency_key: str) -> dict[str, Any]:
    return _service().create_registration(payload, idempotency_key)


def update_registration(registration_id: str, expected_version: int, patch: dict[str, Any]) -> dict[str, Any]:
    return _service().update_registration(registration_id, expected_version, patch)


def cancel_registration(registration_id: str, expected_version: int) -> dict[str, Any]:
    return _service().cancel_registration(registration_id, expected_version)


def expire_registrations(now: str) -> int:
    return _service().expire_registrations(now)


def export_active_groups(now: str) -> dict[str, Any]:
    return _service().export_active_groups(now)


def export_events(since_event_id: int = 0) -> list[dict[str, Any]]:
    return _service().export_events(since_event_id)
