# HANDOFF

版本：`member-a-p0/0.1.1`

## 已完成

- 可运行旅客/管理双端；mock/http assist 适配器。
- DecisionResult 六类业务状态 + HTTP 409/timeout/5xx 技术失败分离。
- card/text 两版使用同一 DecisionResult，统一匿名埋点。
- 条件变化、input_version、旧响应丢弃。
- SQLite 登记：幂等、同行组唯一、版本冲突、状态机、取消、过期、事件、重启、人数守恒、精确约束聚合。
- 管理端聚合与独立 dispatch mock；未实现车辆优化。
- 19 个自动测试、固定 9 项故障回放、真实 HTTP smoke、360px 浏览器布局检查。
- 已补条件变化即时失效、上游响应关联校验、过期后重新登记和严格数值/版本校验。

## 队长接线入口

1. Assist：设置 `ASSIST_ADAPTER=http` 与 `ASSIST_BASE_URL`，A 会调用 `/v1/assist`。
2. 登记：直接导入 `registration.RegistrationService`；不需要把 A 的 FastAPI 当成第二个主后端。
3. 聚合：`export_active_groups(now)` 返回 `results/aggregation_example.json` 同形状。
4. 事件：`export_events(since_event_id)`；UI 匿名日志可从 `/api/ui-events` 导出 JSONL。
5. Dispatch：A 当前只有 `MockDispatchAdapter`。队长定义 `/v1/dispatch/preview` 详细格式后再替换适配器；A 不补车辆算法。

## 需要队长确认

- `contract_change_request.md`：AggregationResult 多 mode 表达。
- 真实 `/v1/assist` BASE_URL、错误体格式是否沿用 `{code,message}`。
- `/v1/dispatch/preview` 的正式字段（尤其未服务人数/原因、求解状态、来源、方案版本）。

## 交给 B

- UI variant：`text` / `card`。
- task 埋点类型与 JSONL 例子：`docs/EVENT_SCHEMA.md`、`results/ui_events_example.jsonl`。
- 当前技术构建：`member-a-p0/0.1.1`。
- 360px 技术检查通过；真人试用尚未执行。
- 已知限制：mock 内容不是实际出行建议；无真实后端联调；匿名跨设备不能完全消重。

## 本轮实际测试与失败

- `python -m unittest ...`：19/19 PASS。
- `experiments/reliability_replay.py`：完整模块 9/9 PASS；基线暴露4类预期失败机制。
- FastAPI HTTP smoke：health、assist、create registration、aggregation、events、dispatch mock 均 200。
- 取消 smoke：取消后 active groups=0，`excluded_counts.cancelled=1`。
- 360px：Chromium 布局无横向溢出；localhost 浏览器导航受本执行环境管理员策略阻止，因此浏览器检查采用 fetch stub，真实 HTTP 已单独验证。这一环境限制已保留，不隐藏。

## 每日5行回传

1. 已完成可运行成果：旅客/管理P0、登记状态机、双UI、mock/http、可靠性回放。
2. 文件/版本：`workstreams/member_a/`，`member-a-p0/0.1.0`。
3. 测试及失败：19/19；固定回放9/9；HTTP核心链路200；基线按设计失败；Chromium localhost 被环境策略拦截。
4. 需要对方：真实 assist URL、dispatch preview 正式字段、AggregationResult 多mode决策。
5. 下一步：与队长真实接口联调，再进入 P1 200+ 合成序列与 B 的试用支持。
